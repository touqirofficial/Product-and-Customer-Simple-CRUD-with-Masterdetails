﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Masterdetails_Mvc.Models.ViewModels
{
    public class CustomerVM
    {
        public int CustomerId { get; set; }
        [Required, Display(Name = "Customer Name"), StringLength(50)]
        public string CustomerName { get; set; }
        [Required, Display(Name = "Purchase Date"), DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime PurchaseDate { get; set; }
        public string Phone { get; set; }
        public string Picture { get; set; }
        [Display(Name = "Picture")]
        public HttpPostedFileBase PictureFile { get; set; }
        [Display(Name = "Exicute")]
        public bool Status { get; set; }

        public List<int> Productlist { get; set; } = new List<int>();
    }
}