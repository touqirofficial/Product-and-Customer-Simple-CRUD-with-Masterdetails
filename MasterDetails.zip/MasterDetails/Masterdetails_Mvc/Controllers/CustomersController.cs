﻿using Masterdetails_Mvc.Models;
using System;
using System.Data.Entity;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Masterdetails_Mvc.Models.ViewModels;
using System.IO;

namespace Masterdetails_Mvc.Controllers
{
    public class CustomersController : Controller
    {
        ProductBbContext db= new ProductBbContext();
        public ActionResult Index()
        {
            var Customer = db.Customers.Include(c => c.BookingEntries.Select(b => b.Product)).OrderByDescending(x => x.CustomerId).ToList();
            return View(Customer);
        }

        public ActionResult AddNewProducts(int ? id)
        {
            ViewBag.product = new SelectList(db.Products.ToList(), "ProductId", "ProductName", (id != null) ? id.ToString() : "");
            return PartialView("_AddNewProducts");
        }

        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(CustomerVM customerVM , int[] productId)
        {
            if (ModelState.IsValid)
            {
                Customer customer = new Customer()
                {
                    CustomerName = customerVM.CustomerName,
                    PurchaseDate = customerVM.PurchaseDate,
                    Phone = customerVM.Phone,
                    Status = customerVM.Status
                };

                HttpPostedFileBase file = customerVM.PictureFile;
                if (file != null)
                {
                    string filePath = Path.Combine("/Images", DateTime.Now.Ticks.ToString() + Path.GetExtension(file.FileName));
                    file.SaveAs(Server.MapPath(filePath));
                    customer.Picture = filePath;
                }
                foreach (int item in productId)
                {
                    BookingEntry bookingEntry = new BookingEntry()
                    {
                        Customer = customer,
                        CustomerId = customerVM.CustomerId,
                        ProducId = item
                    };
                    db.BookingEntries.Add(bookingEntry);
                }
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View();
        }

        public ActionResult Edit(int ? id)
        {
            Customer customer = db.Customers.First(x => x.CustomerId == id);
            var CustomerProduct = db.BookingEntries.Where(x => x.CustomerId == id).ToList();

            CustomerVM customerVM = new CustomerVM()
            {
                CustomerId = customer.CustomerId,
                CustomerName = customer.CustomerName,
                PurchaseDate = customer.PurchaseDate,
                Phone = customer.Phone,
                Picture= customer.Picture,  
                Status = customer.Status
            };

            if (CustomerProduct.Count() > 0)
            {
                foreach (var item in CustomerProduct)
                {
                    customerVM.Productlist.Add(item.ProducId);
                }
            }
            return View(customerVM);
        }

        [HttpPost]
        public ActionResult Edit(CustomerVM customerVM, int[] productId)
        {
            if (ModelState.IsValid)
            {
                Customer customer = new Customer()
                {
                    CustomerId = customerVM.CustomerId,
                    CustomerName = customerVM.CustomerName,
                    PurchaseDate = customerVM.PurchaseDate,
                    Phone = customerVM.Phone,
                    Status = customerVM.Status
                };

                //Image
                HttpPostedFileBase file = customerVM.PictureFile;
                if (file != null)
                {
                    string filePath = Path.Combine("/Images", DateTime.Now.Ticks.ToString() + Path.GetExtension(file.FileName));
                    file.SaveAs(Server.MapPath(filePath));
                    customer.Picture = filePath;
                }
                else
                {
                    //string fName= clientVM.PictureFile.FileName.ToString();
                    customer.Picture = customerVM.Picture;
                }

                //spot delete
                var existsSpotEntry = db.BookingEntries.Where(x => x.CustomerId == customer.CustomerId).ToList();

                foreach (var bookingEntry in existsSpotEntry)
                {
                    db.BookingEntries.Remove(bookingEntry);
                }

                //Add Spot
                foreach (var item in productId)
                {
                    BookingEntry bookingEntry = new BookingEntry()
                    {
                        Customer = customer,
                        CustomerId = customer.CustomerId,
                        ProducId = item
                    };
                    db.BookingEntries.Add(bookingEntry);
                }
                db.Entry(customer).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View();
        }
        public ActionResult Delete(int? id)
        {
            var Customer = db.Customers.Find(id);
            var existsSpotEntry = db.BookingEntries.Where(x => x.CustomerId == Customer.CustomerId).ToList();

            foreach (var bookingEntries in existsSpotEntry)
            {
                db.BookingEntries.Remove(bookingEntries);
            }
            db.Entry(Customer).State = EntityState.Deleted;
            db.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}
