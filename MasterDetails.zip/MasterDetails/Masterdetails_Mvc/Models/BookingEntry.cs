﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Masterdetails_Mvc.Models
{
    public class BookingEntry
    {
        public int BookingEntryId { get; set; }
        [ForeignKey("Customer")]
        public int CustomerId { get; set; }
        [ForeignKey("Product")]
        public int ProducId { get; set; }

        //nev
        public virtual Customer  Customer { get; set; }
        public virtual Product Product { get; set; }
    }
}