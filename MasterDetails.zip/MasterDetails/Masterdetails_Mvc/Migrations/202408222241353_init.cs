﻿namespace Masterdetails_Mvc.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class init : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.BookingEntries",
                c => new
                    {
                        BookingEntryId = c.Int(nullable: false, identity: true),
                        CustomerId = c.Int(nullable: false),
                        ProducId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.BookingEntryId)
                .ForeignKey("dbo.Customers", t => t.CustomerId, cascadeDelete: true)
                .ForeignKey("dbo.Products", t => t.ProducId, cascadeDelete: true)
                .Index(t => t.CustomerId)
                .Index(t => t.ProducId);
            
            CreateTable(
                "dbo.Customers",
                c => new
                    {
                        CustomerId = c.Int(nullable: false, identity: true),
                        CustomerName = c.String(nullable: false, maxLength: 50),
                        PurchaseDate = c.DateTime(nullable: false),
                        Phone = c.String(),
                        Picture = c.String(),
                        Status = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.CustomerId);
            
            CreateTable(
                "dbo.Products",
                c => new
                    {
                        ProductId = c.Int(nullable: false, identity: true),
                        ProductName = c.String(),
                    })
                .PrimaryKey(t => t.ProductId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.BookingEntries", "ProducId", "dbo.Products");
            DropForeignKey("dbo.BookingEntries", "CustomerId", "dbo.Customers");
            DropIndex("dbo.BookingEntries", new[] { "ProducId" });
            DropIndex("dbo.BookingEntries", new[] { "CustomerId" });
            DropTable("dbo.Products");
            DropTable("dbo.Customers");
            DropTable("dbo.BookingEntries");
        }
    }
}
