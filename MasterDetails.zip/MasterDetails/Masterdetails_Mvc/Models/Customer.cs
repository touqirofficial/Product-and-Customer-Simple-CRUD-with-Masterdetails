﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Masterdetails_Mvc.Models
{
    public class Customer
    {
        public int CustomerId { get; set; }
        [Required, Display(Name = "Customer Name"), StringLength(50)]
        public string CustomerName { get; set; }
        [Required, Display(Name = "Purchase Date"), DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime PurchaseDate { get; set; }
        public string Phone { get; set; }
        public string Picture { get; set; }
        [Display(Name ="Exicute")]
        public bool Status { get; set; }
        public ICollection<BookingEntry> BookingEntries { get; set; } = new List<BookingEntry>();
    }
}